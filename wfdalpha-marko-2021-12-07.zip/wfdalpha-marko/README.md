# React-Static - LoTerra Interface

To use this template, run `Yarn start`.
